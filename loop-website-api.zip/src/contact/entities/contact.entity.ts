import { Entity, Column, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';
import { ContactStatus } from '../contact-status.enum';


@Entity()
export class Contact {
  @PrimaryGeneratedColumn('uuid')
  contactId: string;

  @Column({ type: 'varchar', length: 100 })
  name: string;

  @Column({ type: 'varchar', length: 255 })
  email: string;

  @Column({ type: 'varchar', length: 50 })
  phone: string;

  @Column({ type: 'text' })
  description: string;

  @Column({
    type: 'enum',
    enum: ContactStatus,
    default: ContactStatus.PENDING,
  })
  status: ContactStatus;
  @Column({ type: 'varchar', length: 50 })
  propertyId: string;

  @CreateDateColumn()
  createdAt: Date;
}