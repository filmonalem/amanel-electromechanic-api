"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateAuthenticationDto = void 0;
var CreateAuthenticationDto = /** @class */ (function () {
    function CreateAuthenticationDto() {
    }
    return CreateAuthenticationDto;
}());
exports.CreateAuthenticationDto = CreateAuthenticationDto;
